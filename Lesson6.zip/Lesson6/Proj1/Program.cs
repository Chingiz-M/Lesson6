﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj1
{
    class Program
    {/* Задание: 1. Изменить программу вывода функции так, чтобы можно было передавать функции типа double (double,double).
                    Продемонстрировать работу на функции с функцией a*x^2 и функцией a*sin(x).
        Фамилия: Орлов
      */
        static void Main()
        {
            Console.Title = "Делегаты";
            Table(MyFunc, 2.3, 1.4, "a*x^2");
            Table((a,x) => a*Math.Sin(x), 2.3, 1.4, "a*sin(x)");
            Console.ReadKey(true);
        }
        public static void Table(Func<double, double, double> F, double a, double x, string function)
        {
            Console.WriteLine($"a = {a}; x = {x} => {function} = {F(a, x)}");
        }
        public static double MyFunc(double a, double x) // a*x^2 
        {
            double multi = a * x;

            byte[] multiArray = GetBytesBlock(multi);
            byte[] Array2 = GetBytesBlock(2);
            byte[] resArray = new byte[sizeof(double)];

            for (int i = 0; i < sizeof(double); i++)
                resArray[i] = (byte)(Array2[i] ^ multiArray[i]);// произвожу XOR и получаю double
            return GetDouble(resArray);
        }
        public static byte[] GetBytesBlock(double values)
        {
            var result = new byte[sizeof(double)];
            double[] src = { values };
            Buffer.BlockCopy(src, 0, result, 0, result.Length);
            return result;
        }
        public static double GetDouble(byte[] bytes)
        {
            var result = new double[bytes.Length / sizeof(double)];
            Buffer.BlockCopy(bytes, 0, result, 0, bytes.Length);
            return result[0];
        }

    }
}
