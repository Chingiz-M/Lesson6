﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Proj3
{
    class Program
    {/* Задание: 3. Переделать программу «Пример использования коллекций» для решения следующих задач:
                 а) Подсчитать количество студентов учащихся на 5 и 6 курсах;
                 б) подсчитать сколько студентов в возрасте от 18 до 20 лет на каком курсе учатся (частотный массив);
                 в) отсортировать список по возрасту студента;
                 г) *отсортировать список по курсу и возрасту студента;
                 д) разработать единый метод подсчета количества студентов по различным параметрам
                 выбора с помощью делегата и методов предикатов.
        Фамилия: Орлов
      */
        static void Main(string[] args)
        {
            // немного не понял задание д), но готов выполнить, если объясните поподробнее, а так количество посчитать несложно
            Console.Title = "Коллекции";
            List<Students> ListStudents = ReadFile("Students.csv");
            Count5_6Courses(ListStudents); // a)
            Count18_20Ages(ListStudents); // б)
            ListStudents.Sort(new Comparison<Students>(MyDelegat)); // в)
            List<Students> NewListStudents = ListStudents.OrderBy(x => x.Course).ThenBy(x => x.Age).ToList(); // г)
            Console.ReadKey();
        }
        public static List<Students> ReadFile(string filename)
        {
            List<Students> list = new List<Students>();
            using (StreamReader sr = new StreamReader(filename, Encoding.GetEncoding(1251)))
            {
                while (!sr.EndOfStream)
                {
                    try
                    {
                        string[] s = sr.ReadLine().Split(';');
                        list.Add(new Students(s));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }
            }
            return list;
        }
        public static void Count5_6Courses(List<Students> ListStudents) 
        {
            int count = 0;
            foreach (var student in ListStudents)
                if (student.Course >= 5)
                    count++;
            Console.WriteLine("Всего студентов на 5 и 6 курсах: " + count);
        }
        public static void Count18_20Ages(List<Students> ListStudents) 
        {
           Dictionary<int, int> pairs = new Dictionary<int, int>();
           Dictionary<int, int> temppairs = new Dictionary<int, int>();
            for (int i = 18; i < 21; i++)
            {
                pairs.Add(i, 0);
                temppairs.Add(i, 0);
            }
            foreach (var student in ListStudents)
                foreach(var key in temppairs.Keys)
                    if (key == student.Age)
                        pairs[key]++;

            foreach (var pair in pairs)
                Console.WriteLine($"Студентов возраста {pair.Key} - {pair.Value} человек");
        }
        public static int MyDelegat(Students st1, Students st2) => st1.Age.CompareTo(st2.Age);

    }
}
