﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj3
{
    class Students
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string University { get; set; }
        public string Faculty { get; set; }
        public string Department { get; set; }
        public int Age { get; set; }
        public int Course { get; set; }
        public int Group { get; set; }
        public string City { get; set; }
        public Students(string[] s)
        {
            LastName = s[0];
            FirstName = s[1];
            University = s[2];
            Faculty = s[3];
            Department = s[4];
            Age = int.Parse(s[5]);
            Course = int.Parse(s[6]);
            Group = int.Parse(s[7]);
            City = s[8];
        }
    }

}
