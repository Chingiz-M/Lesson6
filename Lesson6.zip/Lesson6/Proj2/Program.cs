﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Proj2
{
    class Program
    {/* Задание: 2. Модифицировать программу нахождения минимума функции так, чтобы можно было передавать функцию в виде делегата.
                 а) Сделайте меню с различными функциями и предоставьте пользователю выбор, для какой функции и на каком отрезке находить минимум.
                 б) Используйте массив (или список) делегатов, в котором хранятся различные функции.
                 в) *Переделайте функцию Load, чтобы она возвращала массив считанных значений. Пусть она
                 возвращает минимум через параметр.
        Фамилия: Орлов
      */
        public static Func<double, double>[] Funcs = new Func<double, double>[2]; // пункт б)
        static void Main(string[] args)
        {
            Console.Title = "Минимум функции";
            Funcs[0] = Sin;
            Funcs[1] = Cos;
            SaveFunc("data.bin", -100, 100, 0.5, ChoiceFunc(Funcs));
            double[] Mass = Load("data.bin", out double min);
            Console.WriteLine($"Минимальное число в заданном промежутке: {min}");
            Console.ReadKey(true);
        }
        public static double Sin(double x) => x * Math.Sin(x);
        public static double Cos(double x) => x * Math.Cos(x);
        public static Func<double, double> ChoiceFunc(Func<double, double>[] funcs)// пункт а)
        {
            int num = GetCheckNumFunc();
            Func<double, double> func;
            if (num == 1)
                func = funcs[0];
            else
                func = funcs[1];

            return func;
        }
        public static int GetCheckNumFunc()// пункт а)
        {
            Console.WriteLine("Выберите функцию:\nx*sin(x) (нажмите 1)\nx*cos(x) (нажмите 2)");

            while (true)
            {
                if (Int32.TryParse(Console.ReadLine(), out int num))
                {
                    if (num == 1)
                        return 1;
                    else if (num == 2)
                        return 2;
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Выберите функцию:\nx*sin(x) (нажмите 1)\nx*cos(x) (нажмите 2)");
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Выберите функцию:\nx*sin(x) (нажмите 1)\nx*cos(x) (нажмите 2)");
                }
            }
            
        }
        public static void SaveFunc(string fileName, double a, double b, double h, Func<double,double> func)
        {
            FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            double x = a;
            while (x <= b)
            {
                bw.Write(Math.Round(func(x),3));
                x += h;
            }
            bw.Close();
            fs.Close();
        }
        public static int[] GetCheckSection(FileStream fs)// пункт а)
        {
            long len = fs.Length / sizeof(double);
            Console.WriteLine($"В файле всего {len} чисел, выберите отрезок для нахождения min числа");
            int[] result = new int[2];
            Console.WriteLine("Введите от какого числа искать");

            while (true)
            {
                if (Int32.TryParse(Console.ReadLine(), out int start))
                {
                    if (start <= len && start >= 0)
                    {
                        result[0] = start;
                        break;
                    }    
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Введите от какого числа искать");
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Введите от какого числа искать");
                }
            }
            Console.WriteLine("Введите до какого числа искать");

            while (true)
            {
                if (Int32.TryParse(Console.ReadLine(), out int end))
                {
                    if (end <= len && end >= result[0])
                    {
                        result[1] = end;
                        break;
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Введите до какого числа искать");
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Введите от какого числа искать");
                }
            }
            return result;
        }
        public static double[] Load(string fileName, out double min)
        {
            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            BinaryReader bw = new BinaryReader(fs);
            double[] result = new double[fs.Length / sizeof(double)];
            min = double.MaxValue;
            double d;
            int[] section = GetCheckSection(fs);// пункт а)
            for (int i = 0; i < fs.Length / sizeof(double); i++)
            {
                d = bw.ReadDouble();
                result[i] = d;
                if(i >= section[0] && i <= section[1])// пункт а)
                    if (d < min) min = d;
            }
            bw.Close();
            fs.Close();
            return result;
        }
    }
}
